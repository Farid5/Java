/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coba;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;


/**
 *
 * @author Chronos
 */
public class KoneksiDB {
    
    public static Connection Koneksi;
    
    public static Connection getKoneksi()
    {
        if(Koneksi==null)
        {
            try
            {
             String url="jdbc:mysql://localhost/universitas";
             String usr="root";
             String psw="";
             
             DriverManager.registerDriver(new com.mysql.jdbc.Driver());
             Koneksi = DriverManager.getConnection(url,usr,psw);
             
                System.out.println("Database UP!");
            }
            
            catch(SQLException lol)
            {
                System.out.println("Database Down!");
            }
            
            
        }
        
        
        return Koneksi;
    }
    
}
